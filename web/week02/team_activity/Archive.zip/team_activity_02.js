function userClick() {
    alert("Clicked!");
}
function changeColor(){
    document.getElementById('first').style.backgroundColor = document.getElementById('newColor').value;
}

